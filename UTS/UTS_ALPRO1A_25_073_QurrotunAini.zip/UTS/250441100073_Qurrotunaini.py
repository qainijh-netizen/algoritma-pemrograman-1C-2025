motor_matic = 50.000
motor_trail = 100.000
motor_sport = 75.000

asuransi_per3hari = 15.000
diskon_sewalebihdari30hari = 0.10
diskon_dgnkupon = 0.5

print("===selamat datang di tempat sewa motor===")
print("jenis motor:")
print("1 Motor matic")
print("2 Motor trail")
print("3 Motor sport")

print(input("Jenis motor yang di sewa(masukkan angka!): ")) 
sewa = 0
if sewa == 1:
    print("Harga sewa: ", motor_matic)
    print(input("Waktu Sewa(untuk mennetukan dapat diskon/tidak): "))
    if sewa <= 3:
     print("anda dapat harga normal: ", motor_matic * sewa)
     
    elif sewa >= 3:
       print("selamat! anda mendapatkan asuransi")
       print("Harga yang di dapat: ", motor_matic * sewa - 15.000)
    elif sewa >= 30:
       print("selamat anda mendapat asuransi 100.000")  
       print("Harga yang di dapat: ", motor_matic * sewa - 100.000) 
    else:
       print("tidak ada versi, coba dgn kupon")
    
    
elif sewa == 2:
    print("Harga sewa: ", motor_trail)
    print(input("Waktu Sewa(untuk mennetukan dapat diskon/tidak):"))
    sewa = 0
    if sewa <= 3:
     print("anda dapat harga normal: ", motor_sport)
    elif sewa >= 3:
       print("selamat! anda mendapatkan asuransi")
       print("Harga yang di dapat: ", motor_sport * sewa - 15.000)
    elif sewa >= 30:
       print("selamat anda mendapatkan asuransi sebesar 100.000")
       print("Harga yang didapat: ", motor_sport * sewa - 100.000)   
    else:
       print("tidak ada versi, coba dgn kupon")
elif sewa == 3:
    print("Harga sewa: ", motor_trail)
    print(input("Waktu Sewa(untuk mennetukan dapat diskon/tidak):"))
    sewa = 0
    if sewa <= 3:
     print("anda dapat harga normal: ", motor_trail)
    elif sewa >= 3:
       print("selamat! anda mendapatkan asuransi")
       print("Harga yang di dapat: ", motor_trail - 15.000)  
    elif sewa >= 30:
       print("selamat anda mendapatkan asuransi sebesar 100.000")
       print("Harga yang didapat: ", motor_trail * sewa - 100.000)
    else:
       print("tidak ada versi, coba dgn kupon")      

else:
    print("Masukan angka yang sesuai!")



